
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'h3lltronik',
  applicationName: 'accountant-tools-api',
  appUid: '19rQN2Kh8JRzD0V49m',
  orgUid: 'efeb513a-25dd-4826-96a8-dba164cf0f00',
  deploymentUid: '0c5e1da7-d588-47a8-b87f-d47df932f523',
  serviceName: 'accountant-chatbot',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'accountant-chatbot-dev-main', timeout: 30 };

try {
  const userHandler = require('./dist/main.js');
  module.exports.handler = serverlessSDK.handler(userHandler.lambdaHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}